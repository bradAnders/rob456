Execute these lines to run code

$roslaunch rob456_project rob456_project.launch

$roslaunch nav_bundle nav_bundle.launch
